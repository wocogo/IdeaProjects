define([], function(){
	return {
		getUrl: function(thisPath){
			return thisPath + '/countryStore.json';
		},

		layouts: [
		]
	};
});
